import numpy as np
from matplotlib import pyplot as plt
from PIL import Image
import os
import random
from tensorflow import keras
from tensorflow.keras.callbacks import Callback


class LossTracker(Callback):
    """Custom callback to track and store training and validation loss and accuracy.

        This callback records the loss and accuracy metrics for both training
        and validation phases at the end of each batch and at the end of each epoch.
        It can be useful for monitoring model performance during training and
        visualizing the training process.

        Attributes:
            train_loss_tracker: List to store training loss values.
            train_accuracy_tracker: List to store training accuracy values.
            validation_loss_tracker: List to store validation loss values.
            validation_accuracy_tracker: List to store validation accuracy values.
    """

    def __init__(self):
        super(LossTracker, self).__init__()
        self.train_loss_tracker = []
        self.train_accuracy_tracker = []
        self.validation_loss_tracker = []
        self.validation_accuracy_tracker = []

    def on_train_batch_end(self, batch, logs=None):
        """Store training loss and accuracy at the end of each batch."""
        self.train_loss_tracker.append(logs.get('loss'))
        self.train_accuracy_tracker.append(logs.get('accuracy'))

        self.validation_loss_tracker.append(logs.get('val_loss'))
        self.validation_accuracy_tracker.append(logs.get('val_accuracy'))

    def on_epoch_end(self, epoch, logs=None):
        """Store validation loss and accuracy at the end of each epoch and print the metrics."""
        val_loss = logs.get('val_loss')
        val_accuracy = logs.get('val_accuracy')

        self.validation_loss_tracker.append(val_loss)
        self.validation_accuracy_tracker.append(val_accuracy)

        print(f"Epoch {epoch + 1}:")
        print(f"  Training   - loss: {logs.get('loss'):.4f}, accuracy: {logs.get('accuracy'):.4f}")
        print(f"  Validation - loss: {val_loss:.4f}, accuracy: {val_accuracy:.4f}")
        print()


def moving_average(data, window_size):
    return np.convolve(data, np.ones(window_size) / window_size, mode='valid')


def plot_metrics(loss_results, window_size=150):
    """
    Plots the training and validation loss and accuracy over batches/epochs.

    Parameters:
    - loss_results: An object containing the following attributes:
        - train_loss_tracker (list): Training loss values per batch.
        - validation_loss_tracker (list): Validation loss values (None for batches, valid for epochs).
        - train_accuracy_tracker (list): Training accuracy values per batch.
        - validation_accuracy_tracker (list): Validation accuracy values (None for batches, valid for epochs).
    - window_size (int): The window size for smoothing the plots (default is 150).
    """
    # Extract metrics from loss_results
    train_losses = loss_results.train_loss_tracker
    val_losses = loss_results.validation_loss_tracker
    train_accuracies = loss_results.train_accuracy_tracker
    val_accuracies = loss_results.validation_accuracy_tracker

    # Define the number of batches (epochs)
    batches = range(1, len(train_losses) + 1)

    # Moving averages for training metrics
    smoothed_train_losses = moving_average(train_losses, window_size)
    smoothed_train_accuracies = moving_average(train_accuracies, window_size)

    # Filter out None values for validation metrics
    val_loss_indices = [i for i, v in enumerate(val_losses) if v is not None]
    val_acc_indices = [i for i, v in enumerate(val_accuracies) if v is not None]

    plt.figure(figsize=(12, 5))

    # Plot Loss
    plt.subplot(1, 2, 1)
    plt.plot(batches, train_losses, label='Training Loss', color='r', linestyle='-', alpha=0.25)
    plt.plot(batches[window_size - 1:], smoothed_train_losses, label='Smoothed Training Loss', color='r', linestyle='-')
    plt.scatter(val_loss_indices, [val_losses[i] for i in val_loss_indices], label='Validation Loss', color='g', marker='x')
    plt.xlabel('Batch')
    plt.ylabel('Loss')
    plt.title('Training and Validation Loss Over Batches')
    plt.grid(True)
    plt.legend()

    # Plot Accuracy
    plt.subplot(1, 2, 2)
    plt.plot(batches, train_accuracies, label='Training Accuracy', color='b', linestyle='-', alpha=0.25)
    plt.plot(batches[window_size - 1:], smoothed_train_accuracies, label='Smoothed Training Accuracy', color='b', linestyle='-')
    plt.scatter(val_acc_indices, [val_accuracies[i] for i in val_acc_indices], label='Validation Accuracy', color='m', marker='x')
    plt.xlabel('Batch')
    plt.ylabel('Accuracy (%)')
    plt.title('Training and Validation Accuracy Over Batches')
    plt.grid(True)
    plt.legend()

    plt.tight_layout()
    plt.show()


def show_random_samples(base_dir, digit):
    """
        Displays 4 random images from the specified digit directory.

        Parameters:
        - base_dir (str): The base directory containing digit-classified subdirectories.
        - digit (int): The digit class (0-9) from which to sample images.
    """
    target_dir = os.path.join(base_dir, str(digit))

    # Check if the directory exists
    if not os.path.exists(target_dir):
        print(f"Directory {target_dir} does not exist.")
        return

    # List all files in the directory
    files = os.listdir(target_dir)

    # Filter out non-image files (if necessary)
    files = [file for file in files if file.endswith(('.jpg', '.jpeg', '.png'))]

    # Check if there are at least 4 images
    if len(files) < 4:
        print(f"Not enough images in {target_dir}. Found only {len(files)} images.")
        return

    # Randomly select 4 images
    random_samples = random.sample(files, 4)

    # Plot the selected images
    plt.figure(figsize=(10, 10))

    for i, sample in enumerate(random_samples):
        img_path = os.path.join(target_dir, sample)
        img = Image.open(img_path)

        # Plot the image
        plt.subplot(2, 2, i + 1)
        plt.imshow(img, cmap='grey')
        plt.axis('off')
        plt.title(f"Sample {i + 1}")

    plt.show()


def visualize_neural_network_fx(model, directory='validation_set', digit=9):
    """
    This function visualizes the feature maps produced by the first convolutional layer
    and the output of the first max pooling layer of a trained Keras model when applied
    to a randomly selected image from a directory corresponding to a specific digit class.
    It also displays the original image.
    """

    # Set the directory path based on the chosen digit
    base_path = f'{directory}/{digit}/'

    # Get a list of all image files in the directory
    image_files = os.listdir(base_path)

    # Randomly select one image file
    random_image = random.choice(image_files)
    print(f"Selected image: {random_image}")

    # Full path to the selected image
    image_path = os.path.join(base_path, random_image)

    # Load and preprocess the selected image (assuming grayscale images)
    input_image = keras.preprocessing.image.load_img(image_path, color_mode='grayscale', target_size=(28, 28))
    input_image = keras.preprocessing.image.img_to_array(input_image)
    original_image = input_image.copy()  # Save a copy of the original image
    input_image = input_image / 255.0  # Normalize the image

    # Create models that output the feature maps of the first Conv2D layer and the first MaxPooling2D layer
    conv_layer_model = keras.Model(inputs=model.input, outputs=model.layers[0].output)
    pool_layer_model = keras.Model(inputs=model.input, outputs=model.layers[1].output)

    # Reshape input image to add batch dimension (needed by the model)
    input_image = np.expand_dims(input_image, axis=0)

    # Pass the image through the convolutional layer to get the feature maps
    feature_maps = conv_layer_model.predict(input_image)

    # Pass the image through the pooling layer to get the pooled feature maps
    pooled_feature_maps = pool_layer_model.predict(input_image)

    # Plot the original image
    plt.figure(figsize=(6, 6))
    plt.imshow(original_image[:, :, 0], cmap='gray')
    plt.axis('off')
    plt.title('Original Image')
    plt.show()

    # Display the convolutional feature maps
    num_filters = feature_maps.shape[-1]
    fig, axes = plt.subplots(num_filters // 8 + (num_filters % 8 > 0), 8, figsize=(16, (num_filters // 8 + 1) * 2))
    axes = axes.flatten()  # Flatten the axes array for easy indexing

    for i in range(num_filters):
        feature_map = feature_maps[0, :, :, i]
        axes[i].imshow(feature_map, cmap='gray')
        axes[i].axis('off')
        axes[i].set_title(f'Conv Kernel {i + 1}')

    # Hide any remaining unused subplots
    for j in range(i + 1, len(axes)):
        axes[j].axis('off')

    plt.tight_layout()
    plt.show()

    # Display the pooled feature maps
    num_pooled_filters = pooled_feature_maps.shape[-1]
    fig, axes = plt.subplots(num_pooled_filters // 8 + (num_pooled_filters % 8 > 0), 8, figsize=(16, (num_pooled_filters // 8 + 1) * 2))
    axes = axes.flatten()  # Flatten the axes array for easy indexing

    for i in range(num_pooled_filters):
        pooled_feature_map = pooled_feature_maps[0, :, :, i]
        axes[i].imshow(pooled_feature_map, cmap='gray')
        axes[i].axis('off')
        axes[i].set_title(f'Pooled image {i + 1}')

    # Hide any remaining unused subplots
    for j in range(i + 1, len(axes)):
        axes[j].axis('off')

    plt.tight_layout()
    plt.show()



def load_data(directory):
    """
        Loads images and labels from the specified directory for digits 0-9.

        Parameters:
        - directory (str): The base directory containing digit-classified subdirectories.

        Returns:
        - images (ndarray): Array of loaded images.
        - labels (ndarray): Array of corresponding labels (digits).
    """
    images = []
    labels = []
    MAX_PER_DIGIT = 999
    for digit in range(10):
        digit_dir = os.path.join(directory, str(digit))
        count = 0
        for img_name in os.listdir(digit_dir):
            img_path = os.path.join(digit_dir, img_name)
            img = Image.open(img_path).convert('L')
            img = img.resize((28, 28))
            img_array = np.array(img) / 255.0  # Normalize to [0, 1]
            img_array = img_array.reshape(28, 28, 1)  # Add channel dimension
            images.append(img_array)
            labels.append(digit)
            count += 1
            if count == MAX_PER_DIGIT:
                break
    return np.array(images), np.array(labels)


def visualize_digit_prediction(model, directory='validation_set', digit=9, israndom=True):
    """
    This function visualizes a randomly selected image (or a specific image) from a given digit class,
    and displays the neural network's prediction probabilities for each digit class.

    Parameters:
    - model (keras.Model): The trained Keras model for digit classification.
    - directory (str): The directory containing digit-classified subdirectories.
                       Default is 'validation_set'.
    - digit (int): The digit class (0-9) from which a random image will be selected.
                   Default is 9.

    Steps:
    1. It selects an image (randomly or specifically provided).
    2. It processes the image (normalization, reshaping) and feeds it into the model.
    3. It displays the original image.
    4. It shows a bar plot of the model's prediction probabilities for each digit class.
    """
    # Set the directory path based on the chosen digit
    base_path = f'{directory}/{digit}/'

    # Get a list of all image files in the directory
    image_files = os.listdir(base_path)

    # Randomly select one image file
    random_image = random.choice(image_files)
    if israndom == False:
      random_image = image_files[0]
    
    print(f"Selected image: {random_image}, for digit: {digit}")

    # Full path to the selected image
    image_path = os.path.join(base_path, random_image)

    # Load and preprocess the selected image
    input_image = keras.preprocessing.image.load_img(image_path, color_mode='grayscale', target_size=(28, 28))
    input_array = keras.preprocessing.image.img_to_array(input_image)
    input_array = input_array / 255.0  # Normalize the image

    # Reshape input image to add batch dimension (needed by the model)
    input_array = np.expand_dims(input_array, axis=0)

    # Get model predictions
    predictions = model.predict(input_array)

    # Create a figure with two subplots
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))

    # Display the original image
    ax1.imshow(input_image, cmap='gray')
    ax1.set_title('Input Image')
    ax1.axis('off')

    # Display the prediction probabilities
    digits = range(10)
    ax2.bar(digits, predictions[0] * 100)
    ax2.set_xlabel('Digit Prediction')
    ax2.set_ylabel('Prediction Probability (%)')
    # ax2.set_title('Model Predictions')
    ax2.set_xticks(digits)
    ax2.set_ylim(0, 100)

    # Add percentage labels on top of each bar
    for i, v in enumerate(predictions[0]):
        ax2.text(i, v * 100 + 1, f'{v * 100:.1f}%', ha='center', va='bottom')

    plt.tight_layout()
    plt.show()

    # Print the predicted digit
    predicted_digit = np.argmax(predictions)
    print(f"The model predicts this image is a {predicted_digit}")
    print(f"Confidence: {predictions[0][predicted_digit] * 100:.2f}%")
    print()
